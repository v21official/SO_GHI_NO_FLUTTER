import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import { createLogger } from 'redux-logger';

import appReducer from './slices/app.slices';
import authReducer from './slices/auth.slice';
import bookReducer from './slices/book.slice';
import bookCategoryReducer from './slices/bookCategory.slice';
import bookPositionReducer from './slices/bookPosition.slice';
import publisherReducer from './slices/publisher.slice';
import readerReducer from './slices/reader.slice';
import rentedBookReducer from './slices/rentedBook.slice';
import userReducer from './slices/user.slice';

export const store = configureStore({
  reducer: {
    app: appReducer,
    auth: authReducer,
    user: userReducer,
    reader: readerReducer,
    rentedBook: rentedBookReducer,
    book: bookReducer,
    bookCategory: bookCategoryReducer,
    bookPosition: bookPositionReducer,
    publisher: publisherReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(process.env.NODE_ENV === 'development' ? [createLogger({ collapsed: true })] : []),
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<ReturnType, RootState, unknown, Action<string>>;
