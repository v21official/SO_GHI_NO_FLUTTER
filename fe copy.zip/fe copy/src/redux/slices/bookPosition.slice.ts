import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import { MESSAGE, ResponseStatusEnum } from 'src/const';
import { getListBookPosition, IBookPosition } from 'src/services/bookPosition';

import { AppThunk } from '../store';

type BookPositionState = {
  loading: boolean;
  error: string;
  listBookPosition: IBookPosition[];
};

const initialState: BookPositionState = {
  loading: false,
  error: '',
  listBookPosition: [],
};

export const slice = createSlice({
  name: 'bookPosition',
  initialState,
  reducers: {
    setLoading: (state: BookPositionState, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state: BookPositionState, action: PayloadAction<string>) => {
      state.error = action.payload;
    },
    setListBookPosition: (state: BookPositionState, action: PayloadAction<IBookPosition[]>) => {
      state.listBookPosition = action.payload;
    },
  },
});

export const { setLoading, setError, setListBookPosition } = slice.actions;

export const getListBookPositionAction = (): AppThunk => async (dispatch) => {
  dispatch(setLoading(true));
  const response = await getListBookPosition();
  if (response.status === ResponseStatusEnum.SUCCESS) {
    const { items } = response.data;
    dispatch(setListBookPosition(items));
  } else {
    dispatch(setLoading(false));
    dispatch(setListBookPosition([]));
    return MESSAGE.getListBookPositionError;
  }
  dispatch(setLoading(false));
};

export default slice.reducer;
