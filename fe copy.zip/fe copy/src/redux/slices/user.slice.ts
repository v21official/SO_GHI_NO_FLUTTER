import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import { DEFAULT_PAGE_SIZE, MESSAGE, ResponseStatusEnum } from 'src/const';
import { getListUser, IParamsSearchUser, IUser } from 'src/services/user';
import { TPagination } from 'src/types';

import { AppThunk, RootState } from '../store';

type MemberState = {
  loading: boolean;
  error: string;
  pagination: TPagination;
  users: IUser[];
  userAuth?: IUser;
};

const initialState: MemberState = {
  loading: false,
  error: '',
  pagination: {
    totalItem: 0,
    itemPerPage: DEFAULT_PAGE_SIZE,
    totalPage: 0,
    currentPage: 1,
  },
  users: [],
};

export const slice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setLoading: (state: MemberState, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state: MemberState, action: PayloadAction<string>) => {
      state.error = action.payload;
    },
    setUserAuth: (state: MemberState, action: PayloadAction<IUser>) => {
      state.userAuth = action.payload;
    },
    setListUser: (state: MemberState, action: PayloadAction<IUser[]>) => {
      state.users = action.payload;
    },
    setPagination: (state: MemberState, action: PayloadAction<TPagination>) => {
      state.pagination = action.payload;
    },
  },
});

export const { setLoading, setError, setUserAuth, setListUser, setPagination } = slice.actions;

export const listUser = (state: RootState) => state.user.users;

export const getListUserAction =
  (params: IParamsSearchUser): AppThunk =>
  async (dispatch) => {
    dispatch(setLoading(true));
    const response = await getListUser(params);
    if (response.status === ResponseStatusEnum.SUCCESS) {
      const { totalItem, itemPerPage, totalPage, currentPage, items } = response.data;
      dispatch(setListUser(items));
      dispatch(
        setPagination({
          totalItem,
          itemPerPage,
          totalPage,
          currentPage,
        }),
      );
    } else {
      dispatch(setLoading(false));
      return MESSAGE.getListUserError;
    }
    dispatch(setLoading(false));
  };

export default slice.reducer;
