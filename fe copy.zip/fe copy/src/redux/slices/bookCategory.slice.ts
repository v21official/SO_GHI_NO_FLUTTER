import { createSlice, PayloadAction } from '@reduxjs/toolkit';

import { MESSAGE, ResponseStatusEnum } from 'src/const';
import { getListBookCategory, IBookCategory } from 'src/services/bookCategory';

import { AppThunk } from '../store';

type BookCategoryState = {
  loading: boolean;
  error: string;
  listBookCategory: IBookCategory[];
};

const initialState: BookCategoryState = {
  loading: false,
  error: '',
  listBookCategory: [],
};

export const slice = createSlice({
  name: 'bookCategory',
  initialState,
  reducers: {
    setLoading: (state: BookCategoryState, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state: BookCategoryState, action: PayloadAction<string>) => {
      state.error = action.payload;
    },
    setListBookCategory: (state: BookCategoryState, action: PayloadAction<IBookCategory[]>) => {
      state.listBookCategory = action.payload;
    },
  },
});

export const { setLoading, setError, setListBookCategory } = slice.actions;

export const getListBookCategoryAction = (): AppThunk => async (dispatch) => {
  dispatch(setLoading(true));
  const response = await getListBookCategory();
  if (response.status === ResponseStatusEnum.SUCCESS) {
    const { items } = response.data;
    dispatch(setListBookCategory(items));
  } else {
    dispatch(setLoading(false));
    dispatch(setListBookCategory([]));
    return MESSAGE.getListBookCategoryError;
  }
  dispatch(setLoading(false));
};

export default slice.reducer;
