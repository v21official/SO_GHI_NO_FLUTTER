import { ButtonHTMLType } from 'antd/lib/button/button';

export interface IClassNameProp {
  className?: string;
}
export interface IList<T> {
  items: T[];
  totalItem: number;
  itemPerPage: number;
  totalPage: number;
  currentPage: number;
}
export type MayBe<T> = T | null;

export interface IResponse<T> {
  data: T | null;
  status: number;
  code: number;
  message: string;
}
type TPagination = {
  currentPage: number;
  totalItem: number;
  itemPerPage?: number;
  totalPage?: number;
};
export type TButton = {
  type?: ButtonType;
  icon?: React.ReactNode;
  shape?: ButtonShape;
  size?: SizeType;
  loading?: boolean;
  prefixCls?: string;
  className?: string;
  ghost?: boolean;
  danger?: boolean;
  block?: boolean;
  disabled?: boolean;
  children?: React.ReactNode;
  href?: string;
  target?: string;
  onClick?: React.MouseEventHandler<HTMLElement>;
  htmlType?: ButtonHTMLType;
  id?: any;
};
export interface ISearchInput {
  name: string;
  type: string;
  placeholder: string;
}
