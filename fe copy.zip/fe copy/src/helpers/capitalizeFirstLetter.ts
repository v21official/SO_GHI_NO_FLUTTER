export function capitalizeFirstLetter(stringUpper: string) {
  return stringUpper.charAt(0).toUpperCase() + stringUpper.slice(1).toLowerCase();
}
