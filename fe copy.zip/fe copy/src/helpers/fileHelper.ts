import { message, notification } from 'antd';
import { NotificationPlacement } from 'antd/lib/notification';
import moment, { Moment } from 'moment';

import SOUND_ERROR from 'src/assets/sound/sound_error.mp3';
import SOUND_SUCCESS from 'src/assets/sound/sound_success.mp3';
import { DATE_TIME_FORMAT, MESSAGE } from 'src/const';

export const formatSearchReqData = (params: any) => {
  for (const property in params) {
    if (typeof params[property] === 'string') {
      params[property] = params[property].trim();
    }
    if (params[property] === null || params[property] === undefined || String(params[property]).trim() === '') {
      delete params[property];
    }
  }
};

export const formatReqData = (params: any) => {
  for (const property in params) {
    if (typeof params[property] === 'string') {
      params[property] = params[property].trim();
    }
    if (params[property] === null || params[property] === undefined) {
      delete params[property];
    }
  }
};

export const delay = (millisecond = 1000) => new Promise((resolve) => setTimeout(resolve, millisecond));

export const formatStringDate = (date: string) => {
  // vd: 2022-07-10T23:35:11.000Z
  if (!date) return '';
  return moment(date.split('T')[0]).format(DATE_TIME_FORMAT);
};
export const formatDateRequestAPI = (date: Moment) => {
  if (!date) return '';
  return date.format('YYYY-MM-DD');
};
export const formatDateSetFieldValue = (date: string) => {
  if (!date) return '';
  return moment(date.split('T')[0]);
};
export const playSoundSuccess = () => {
  const audio = new Audio(SOUND_SUCCESS);
  audio.play();
};
export const playSoundError = () => {
  const audio = new Audio(SOUND_ERROR);
  audio.play();
};
export const notificationSuccessAndScrollToTop = () => {
  notification.destroy();
  window.scrollTo({
    top: 0,
    behavior: 'smooth',
  });
  playSoundSuccess();
  notification.success({
    message: 'Thành công!',
  });
};
export const notificationError = (message = MESSAGE.serverError) => {
  notification.destroy();
  playSoundError();
  notification.error({ message });
};
export const notificationWarning = (message: string, description = '', placement: NotificationPlacement = 'top') => {
  notification.warning({ message, description, placement });
};
export const notificationInfo = (message: string, description = '', placement: NotificationPlacement = 'top') => {
  notification.info({ message, description, placement });
};
export const messageError = (messageError = MESSAGE.serverError) => {
  message.destroy();
  playSoundError();
  message.error({
    content: messageError,
    className: 'message-error-custom',
  });
};
