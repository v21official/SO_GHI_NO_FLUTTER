import { EStatusRented } from 'src/pages/RentedBook/components/config';

export interface IRentedBookDetail {
  rentedBookDetailId: number;
  lost: number;
  returnedDate?: string;
  returnedConfirmMemberName?: string;
  returnedConfirmMemberAccount?: string;
  bookCode: string;
  bookName: string;
  categoryLogo: string;
}
export interface IRentedBook {
  id: number;
  rentedBookId: number;
  note?: string;
  readerId: number;
  account?: string;
  cardNumber: number;
  readerName: string;
  borrowedDate: string;
  expectedReturnDate: string;
  returnedDate?: string;
  borrowedConfirmMemberName: string;
  borrowedConfirmMemberAccount: string;
  rentedBookDetail: IRentedBookDetail[];
}
export interface IParamsSearchRentedBook {
  page: number;
  limit: number;
  fromDate?: string;
  toDate?: string;
  cardNumber?: string;
  status?: EStatusRented;
}
export interface IBodyCreateRentedBook {
  readerId: number;
  listBookId: number[];
  note: string;
}
export interface IBodyUpdateRentedBook {
  readerId: number;
  rentedBookId: number;
}
export interface IBodyUpdateRentedBookDetail extends IBodyUpdateRentedBook {
  rentedBookDetailId: number;
  lost: number;
}
export interface IReaderForRentedBook {
  readerId: number;
  memberId: number;
  name: string;
  cardNumber: number;
  account: string;
}
export interface IBookForRentedBook {
  id: number;
  code: string;
  name: string;
  categoryCode: string;
  categoryLogo: string;
  canBorrow: number;
}
