import httpClient from 'src/configs/http-client';
import { jsonConfig } from 'src/const';
import { IList } from 'src/types';

import {
  IBodyCreateRentedBook,
  IBodyUpdateRentedBook,
  IBookForRentedBook,
  IParamsSearchRentedBook,
  IReaderForRentedBook,
  IRentedBook,
} from './rentedBook.interface';

export const getListRentedBook = (params: IParamsSearchRentedBook) => {
  return httpClient.get<IList<IRentedBook>>('/rented/getRentedBookHistory', { params });
};
export const createRentedBook = (body: IBodyCreateRentedBook) => {
  return httpClient.post<IRentedBook>('/rented/createRentedBook', body, jsonConfig);
};
export const updateRentedBook = (body: IBodyUpdateRentedBook) => {
  return httpClient.post<IRentedBook>('/rented/updateRentedBook', body, jsonConfig);
};
export const deleteRentedBook = (id: number) => {
  return httpClient.post<void>('/rented/delete', { id }, jsonConfig);
};
export const getReaderForRented = (search: string) => {
  return httpClient.get<IReaderForRentedBook>('/rented/getReaderForRented', { params: { search } });
};
export const getBookForRented = (search: string) => {
  return httpClient.get<IBookForRentedBook>('/rented/getBookForRented', { params: { search } });
};
