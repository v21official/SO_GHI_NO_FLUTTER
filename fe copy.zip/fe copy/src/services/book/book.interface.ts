import { IBookCategory } from '../bookCategory';
import { IBookPosition } from '../bookPosition';

export interface IBook {
  id: number;
  bookCategoryId: number;
  bookPositionId: number;
  name: string;
  code?: string;
  codeValue: string;
  qty: number;
  available: number;
  note: string;
  description: string;
  author: string;
  publisher: string;
  publishYear: number;
  originBook: string;
  entryDate: string;
  bookCategory?: IBookCategory;
  bookPosition?: IBookPosition;
}
export interface IParamsSearchBook {
  page: number;
  limit: number;
  fromDate?: string;
  toDate?: string;
  search?: string;
  bookCategoryId?: number;
  bookPositionId?: number;
  orderBy?: OrderByBookEnum;
}
export enum OrderByBookEnum {
  ID_ASC = 1,
  ID_DESC = 2,
  DOB_ASC = 3,
  DOB_DESC = 4,
  MONTH_ASC = 5,
  MONTH_DESC = 6,
}
export interface IBodyCreateUpdateBook extends IBook {}
