import { IBookCategory } from '../bookCategory';
import { IBookPosition } from '../bookPosition';
import { IPublisher } from '../publisher';

export interface IParamsLogin {
  account: string;
  password: string;
}
export interface IResponseLogin {
  accessToken: string;
}
export interface IParamsChangePassword {
  currentPassword: string;
  newPassword: string;
}
export interface IHamlet {
  id: number;
  name: string;
}
export interface IRank {
  id: number;
  name: string;
  point: number;
  maxBorrowed: number;
}
export interface IConfigData {
  listRank: IRank[];
  listHamlet: IHamlet[];
  listPublisher: IPublisher[];
  listBookCategory: IBookCategory[];
  listBookPosition: IBookPosition[];
}
