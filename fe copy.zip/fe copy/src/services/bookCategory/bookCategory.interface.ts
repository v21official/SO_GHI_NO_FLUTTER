export interface IBookCategory {
  id: number;
  name: string;
  code: string;
  description: string;
  logo: string;
  point: number;
  canBorrow: number;
  minimumAge?: number;
}
