import httpClient from 'src/configs/http-client';
import { formDataConfig, jsonConfig } from 'src/const';
import { IList } from 'src/types';

import { IBookCategory } from './bookCategory.interface';

export const getListBookCategory = () => {
  return httpClient.get<IList<IBookCategory>>('/bookCategory/getList');
};
export const createBookCategory = (body: IBookCategory) => {
  return httpClient.post<IBookCategory>('/bookCategory/create', body, formDataConfig);
};
export const updateBookCategory = (body: IBookCategory) => {
  return httpClient.post<IBookCategory>('/bookCategory/update', body, formDataConfig);
};
export const deleteBookCategory = (id: number) => {
  return httpClient.post<void>('/bookCategory/delete', { id }, jsonConfig);
};
