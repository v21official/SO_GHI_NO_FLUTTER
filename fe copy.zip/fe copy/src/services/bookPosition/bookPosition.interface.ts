export interface IBookPosition {
  id: number;
  name: string;
  note?: string;
}
