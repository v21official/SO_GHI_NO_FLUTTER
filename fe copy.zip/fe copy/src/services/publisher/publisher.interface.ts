export interface IPublisher {
  id: number;
  name: string;
}
