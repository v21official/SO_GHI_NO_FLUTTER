import React from 'react';

import { RouteProps } from 'react-router-dom';

import { Analytics } from 'src/assets/icons';
import { LoginLayout } from 'src/layouts/LoginLayout';
import { MainLayout } from 'src/layouts/Main';
import { SideBarRoute } from 'src/layouts/Main/main.type';
import { SubAdminLayout } from 'src/layouts/Main/SubAdminLayout';
import { AnalyticsBook } from 'src/pages/Analytics/AnalyticsBook';
import { AnalyticsRented } from 'src/pages/Analytics/AnalyticsRented';
import { Book } from 'src/pages/Book';
import { BookCategory } from 'src/pages/BookCategory';
import { Home } from 'src/pages/Home';
import { Login } from 'src/pages/Login';
import { PageError } from 'src/pages/PageError';
import { Page403 } from 'src/pages/PageError/Page403';
import { Reader } from 'src/pages/Reader';
import { RentedBook } from 'src/pages/RentedBook';
import { Setting } from 'src/pages/Setting';
import { Company } from 'src/pages/SubAdmin/components/Company';
import { Profile } from 'src/pages/SubAdmin/components/Profile';

export interface IRoute extends RouteProps {
  restricted?: boolean;
  layout?: any;
}

interface IConfigRoutes {
  appRoutes: IRoute[];
  isPrivate?: boolean;
  layout?: React.ComponentType;
}

const privateRoutes: IRoute[] = [
  {
    children: <Home />,
    exact: true,
    path: SideBarRoute.HOME,
  },
  {
    children: <Reader />,
    exact: true,
    path: SideBarRoute.READER,
  },
  {
    children: <Book />,
    exact: true,
    path: SideBarRoute.BOOK,
  },
  {
    children: <BookCategory />,
    exact: true,
    path: SideBarRoute.BOOK_CATEGORY,
  },
  {
    children: <RentedBook />,
    exact: true,
    path: SideBarRoute.RENTED_BOOK,
  },
  {
    children: <Setting />,
    exact: true,
    path: SideBarRoute.SETTING,
  },
  {
    children: <AnalyticsRented />,
    exact: true,
    path: SideBarRoute.ANALYTICS_RENTED,
  },
  {
    children: <AnalyticsBook />,
    exact: true,
    path: SideBarRoute.ANALYTICS_BOOK,
  },
];
const publicRoutes: IRoute[] = [
  {
    children: <Login />,
    path: SideBarRoute.LOGIN,
    layout: LoginLayout,
    restricted: true,
  },
];
const noLayoutRoutes: IRoute[] = [
  {
    children: <Page403 />,
    path: '/403',
    restricted: false,
  },
  {
    children: <PageError />,
    path: '/error',
    restricted: false,
  },
];

export const configRoutes: IConfigRoutes[] = [
  {
    appRoutes: privateRoutes,
    isPrivate: true,
    layout: MainLayout,
  },
  {
    appRoutes: publicRoutes,
    layout: MainLayout,
  },
  {
    appRoutes: noLayoutRoutes,
  },
];

//////////////////////////////// sub admin
////////////////////////////////
////////////////////////////////
////////////////////////////////
const subAdminPrivateRoutes: IRoute[] = [
  {
    children: <Profile />,
    exact: true,
    path: SideBarRoute.HOME,
  },
  {
    children: <Company />,
    exact: true,
    path: SideBarRoute.COMPANY,
  },
  {
    children: <Analytics />,
    exact: true,
    path: SideBarRoute.ANALYTICS,
  },
];
export const subAdminConfigRoutes: IConfigRoutes[] = [
  {
    appRoutes: subAdminPrivateRoutes,
    isPrivate: true,
    layout: SubAdminLayout,
  },
];
