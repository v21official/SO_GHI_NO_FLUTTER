import React from 'react';

import { BrowserRouter, Switch } from 'react-router-dom';

import { RestrictedRoute } from 'src/components';
// import { RoleIdEnum } from 'src/const';
import { Page404 } from 'src/pages/PageError/Page404';
// import { useAppSelector } from 'src/redux/hook';
// import { roleConfig } from 'src/redux/slices/appSlice';

import { configRoutes } from './config';

export const AppRoutes: React.FC = () => {
  // const appRoleConfig = useAppSelector(roleConfig);

  return (
    <BrowserRouter>
      <Switch>
        {/* {(appRoleConfig === RoleIdEnum.ADMIN ? configRoutes : subAdminConfigRoutes).map( */}
        {configRoutes.map(({ appRoutes, isPrivate, layout: MainLayout }, i) => {
          return appRoutes.map(({ children, path, layout, ...props }, index) => {
            return (
              <RestrictedRoute isPrivate={isPrivate} path={path} layout={layout || MainLayout} {...props}>
                {children}
              </RestrictedRoute>
            );
          });
        })}
        <RestrictedRoute>
          <Page404 />
        </RestrictedRoute>
      </Switch>
    </BrowserRouter>
  );
};
