import {
  Analytics,
  BookIcon,
  CompanyIcon,
  MemberIcon,
  UserCircleIcon,
  ReaderIcon,
  BookCategoryIcon,
  SettingIcon,
  RentedBookIcon,
} from 'src/assets/icons';

export enum SideBarMenuName {
  HOME = 'TNV',
  READER = 'Bạn đọc',
  BOOK = 'Sách',
  BOOK_CATEGORY = 'Thể loại sách',
  RENTED_BOOK = 'Mượn trả',
  SETTING = 'Cài đặt',

  ANALYTICS = 'Thống kê',
  ANALYTICS_BOOK = 'Thống kê sách',
  ANALYTICS_RENTED = 'Thống kê mượn trả',

  PROFILE = 'Sub Admin Profile',
  COMPANY = 'Company',
}
export enum SideBarRoute {
  HOME = '/',
  LOGIN = '/dang-nhap',
  READER = '/ban-doc',
  BOOK = '/sach',
  BOOK_CATEGORY = '/the-loai-sach',
  RENTED_BOOK = '/muon-tra',
  SETTING = '/cai-dat',

  ANALYTICS = '/thong-ke',
  ANALYTICS_BOOK = '/thong-ke/sach',
  ANALYTICS_RENTED = '/thong-ke/muon-tra',

  COMPANY = '/company',
}

export const SideBarMenu = [
  {
    name: SideBarMenuName.HOME,
    icon: MemberIcon,
    link: SideBarRoute.HOME,
  },
  {
    name: SideBarMenuName.READER,
    icon: ReaderIcon,
    link: SideBarRoute.READER,
  },
  {
    name: SideBarMenuName.BOOK,
    icon: BookIcon,
    link: SideBarRoute.BOOK,
  },
  {
    name: SideBarMenuName.BOOK_CATEGORY,
    icon: BookCategoryIcon,
    link: SideBarRoute.BOOK_CATEGORY,
  },
  {
    name: SideBarMenuName.RENTED_BOOK,
    icon: RentedBookIcon,
    link: SideBarRoute.RENTED_BOOK,
  },
  {
    name: SideBarMenuName.SETTING,
    icon: SettingIcon,
    link: SideBarRoute.SETTING,
  },
  {
    name: SideBarMenuName.ANALYTICS,
    icon: Analytics,
    link: SideBarRoute.ANALYTICS,
    children: [
      {
        name: SideBarMenuName.ANALYTICS_BOOK,
        link: SideBarRoute.ANALYTICS_BOOK,
      },
      {
        name: SideBarMenuName.ANALYTICS_RENTED,
        link: SideBarRoute.ANALYTICS_RENTED,
      },
    ],
  },
];

export const SubAdminMenu = [
  {
    name: SideBarMenuName.PROFILE,
    icon: UserCircleIcon,
    link: SideBarRoute.HOME,
  },
  {
    name: SideBarMenuName.COMPANY,
    icon: CompanyIcon,
    link: SideBarRoute.COMPANY,
  },
  {
    name: SideBarMenuName.ANALYTICS,
    icon: Analytics,
    link: SideBarRoute.ANALYTICS,
  },
];
