import React from 'react';

import '../styles.scss';
import './styles.scss';
import { Layout, Tabs } from 'antd';
import { useHistory, useRouteMatch } from 'react-router-dom';

import { Analytics } from 'src/pages/SubAdmin/components/Analytics';
import { Company } from 'src/pages/SubAdmin/components/Company';
import { Profile } from 'src/pages/SubAdmin/components/Profile';

import { Header } from '../components/LayoutHeader';
import { SideBar } from '../components/LayoutSideBar';
import { SubAdminMenu } from '../main.type';

const TabPane = Tabs.TabPane;
export const SubAdminLayout: React.FC = ({ children }) => {
  const match = useRouteMatch();
  const history = useHistory();
  const { Content } = Layout;
  const subAdminChildren = [<Profile />, <Company />, <Analytics />];
  return (
    <div className="container-page">
      <Layout>
        <SideBar />
        <Layout>
          <Header />
          <Content className="hr-layout-content home-page-sub-admin">
            <Tabs
              hideAdd
              type="editable-card"
              defaultActiveKey={match?.path}
              activeKey={match?.path}
              onChange={(key) => {
                history.push(`${key}`);
              }}
            >
              {SubAdminMenu.map((pane, index) => (
                <TabPane tab={pane.name} key={pane.link}>
                  {subAdminChildren[index]}
                </TabPane>
              ))}
            </Tabs>
          </Content>
        </Layout>
      </Layout>
    </div>
  );
};
