import React, { useState } from 'react';

import { Layout, Menu } from 'antd';
import clsx from 'clsx';
import { useLocation, Link } from 'react-router-dom';

import { ExpandArrow } from 'src/assets/icons';
import './styles.scss';
// import { RoleIdEnum } from 'src/const';
// import { useAppSelector } from 'src/redux/hook';
// import { roleConfig } from 'src/redux/slices/appSlice';

import { SideBarMenu, SideBarRoute } from '../main.type';

const { SubMenu } = Menu;

export const SideBar: React.FC = () => {
  const { Sider } = Layout;
  // const appRoleConfig = useAppSelector(roleConfig);
  const location = useLocation();
  const [collapsed, setCollapsed] = useState<boolean>(true);

  const onCollapse = () => {
    setCollapsed(!collapsed);
  };
  return (
    <div className={clsx('select-none sidebar-container', !collapsed && 'sidebar-container_expand')}>
      <Sider width={290} breakpoint="lg" collapsed={collapsed} collapsible>
        <div className="btn">
          <div className="sidebar-logo">
            <div className="handle-collapse-icon" onClick={onCollapse}>
              <ExpandArrow className={clsx('expand', { isCollapsed: collapsed })} />
            </div>
            <img
              className={clsx('menu-logo', { isCollapsed: collapsed })}
              src={process.env.PUBLIC_URL + '/logo_trang_ngang.png'}
              alt={'logoTVDL'}
            />
          </div>
        </div>
        <Menu theme="dark" mode="inline" selectedKeys={[location.pathname]} className={clsx(collapsed && 'collapsed')}>
          {/* {(appRoleConfig === RoleIdEnum.ADMIN ? SideBarMenu : SubAdminMenu).map((item: any) => { */}
          {SideBarMenu.map((item: any) => {
            if (item.children) {
              return (
                <SubMenu
                  className={clsx(collapsed ? 'collapsed' : 'expanded')}
                  key={item.link}
                  icon={<item.icon />}
                  title={item.name}
                >
                  {item.children.map((subItem: any) => (
                    <Menu.Item key={subItem.link}>
                      <Link to={subItem.link}>{subItem.name}</Link>
                    </Menu.Item>
                  ))}
                </SubMenu>
              );
            }
            return (
              <Menu.Item
                className={clsx(
                  collapsed ? 'collapsed' : 'expanded',
                  [
                    SideBarRoute.BOOK,
                    SideBarRoute.BOOK_CATEGORY,
                    SideBarRoute.RENTED_BOOK,
                    SideBarRoute.SETTING,
                  ].includes(item.link) && 'sidebar-other-icon',
                )}
                key={item.link}
                icon={<item.icon />}
              >
                <Link to={item.link}>{item.name}</Link>
              </Menu.Item>
            );
          })}
        </Menu>
        {collapsed && (
          <div className="menu-bottom-icon">
            <img
              className={clsx('menu-logo', { isCollapsed: collapsed })}
              src={process.env.PUBLIC_URL + '/logo_trang_vuong.png'}
              alt={'logoTVDL'}
            />
          </div>
        )}
      </Sider>
    </div>
  );
};
