import React from 'react';

import './styles.scss';

export const AnalyticsBook: React.FC = () => {
  return <p>AnalyticsBook page</p>;
};
