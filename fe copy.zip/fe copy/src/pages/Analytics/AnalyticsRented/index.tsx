import React from 'react';

import './styles.scss';

export const AnalyticsRented: React.FC = () => {
  return <p>AnalyticsRented page</p>;
};
