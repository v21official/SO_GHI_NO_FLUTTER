import React from 'react';

import { Col, Row } from 'antd';

import Card from '../../components/Card';

import { ListBookPosition, ListPublisher } from './components';

import './styles.scss';

export const Setting: React.FC = () => {
  return (
    <div className="setting-page">
      <Row gutter={24}>
        <Col lg={24} xl={14} xxl={14}>
          <Card>
            <ListBookPosition />
          </Card>
        </Col>
        <Col lg={24} xl={10} xxl={10}>
          <Card>
            <ListPublisher />
          </Card>
        </Col>
      </Row>
    </div>
  );
};
