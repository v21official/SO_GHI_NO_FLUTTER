import { useEffect, useState } from 'react';

import { Form, Input } from 'antd';

import { ButtonPrimary } from 'src/components';
import { ButtonCancel } from 'src/components/Button/ButtonCancel';
import { ModalCustom } from 'src/components/ModalCustom';
import { MESSAGE, PATTERN_NOT_ONLY_SPACE, ResponseStatusEnum } from 'src/const';
import { messageError, notificationSuccessAndScrollToTop } from 'src/helpers';
import { usePermission } from 'src/hooks/usePermission';
import { createBookPosition, IBookPosition, updateBookPosition } from 'src/services/bookPosition';

interface IProps {
  refetchData: () => void;
  onCloseModal: () => void;
  editMode: boolean;
  open: boolean;
  dataDetailBookPosition: IBookPosition | null;
}

export const ModalCreateUpdateBookPosition = ({
  refetchData,
  editMode,
  open,
  onCloseModal,
  dataDetailBookPosition,
}: IProps) => {
  const [form] = Form.useForm();
  const { isAccessBook } = usePermission();
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    loading && setLoading(false);
    if (!dataDetailBookPosition) {
      form.resetFields();
      return;
    }
    form.setFieldsValue({ ...dataDetailBookPosition });
  }, [dataDetailBookPosition]);

  const onFinish = async (values: any) => {
    setLoading(true);
    const body: IBookPosition = {
      ...values,
      id: dataDetailBookPosition?.id,
    };
    const response: any = editMode ? await updateBookPosition(body) : await createBookPosition(body);
    setLoading(false);
    if (response.status === ResponseStatusEnum.ERROR) {
      messageError(response.message);
      return;
    }
    onCloseModal();
    notificationSuccessAndScrollToTop();
    refetchData();
    form.resetFields();
  };

  return (
    <ModalCustom
      open={open}
      className="modal-book-position"
      title={editMode ? 'Sửa thông tin giá sách' : 'Thêm giá sách'}
      loading={loading}
      width={500}
      onCancel={onCloseModal}
    >
      <Form layout="vertical" form={form} onFinish={onFinish}>
        <Form.Item
          name="name"
          label="Tên giá sách"
          rules={[{ required: true }, { pattern: PATTERN_NOT_ONLY_SPACE, message: MESSAGE.stringNotOnlySpace }]}
        >
          <Input type="text" />
        </Form.Item>
        <Form.Item name="note" label="Ghi chú">
          <Input type="text" />
        </Form.Item>
        {isAccessBook && (
          <div className="flex mt-8">
            <ButtonCancel id="btn-cancel" className="w-full mr-2" onClick={onCloseModal}>
              Thoát
            </ButtonCancel>
            <ButtonPrimary id="btn-save" className="w-full ml-2" htmlType="submit">
              Lưu
            </ButtonPrimary>
          </div>
        )}
      </Form>
    </ModalCustom>
  );
};
