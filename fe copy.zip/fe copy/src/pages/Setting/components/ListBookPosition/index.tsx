import React, { useEffect, useState } from 'react';

import { PlusOutlined } from '@ant-design/icons';

import { ButtonSecondary } from 'src/components/Button/ButtonSecondary';
import { ModalConfirmDelete } from 'src/components/ModalConfirmDelete';
import { TableCustom } from 'src/components/TableCustom';
import { DEFAULT_PAGE_SIZE, ResponseStatusEnum } from 'src/const';
import { messageError, notificationSuccessAndScrollToTop } from 'src/helpers/fileHelper';
import { usePermission } from 'src/hooks/usePermission';
import { useAppDispatch, useAppSelector } from 'src/redux/hook';
import { getListBookPositionAction } from 'src/redux/slices/bookPosition.slice';
import { deleteBookPosition, IBookPosition } from 'src/services/bookPosition';

import { ModalCreateUpdateBookPosition } from '../ModalCreateUpdate/ModalCreateUpdateBookPosition';

import { ActionTable } from './ActionTable';

export const ListBookPosition = () => {
  const { loading, listBookPosition } = useAppSelector((state) => state.bookPosition);
  const { isAccessBook } = usePermission();
  const dispatch = useAppDispatch();
  const [editMode, setEditMode] = useState(false);
  const [showModalCreateUpdate, setShowModalCreateUpdate] = useState(false);
  const [dataDetailBookPosition, setDataDetailBookPosition] = useState<IBookPosition | null>(null);

  const [loadingDelete, setLoadingDelete] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [recordDelete, setRecordDelete] = useState<IBookPosition | null>(null);

  const tableColumns: any = [
    {
      title: 'Tên giá sách',
      dataIndex: 'name',
      width: 300,
      render: (name: string, record: IBookPosition) => {
        return (
          <p className="font-semi-bold cursor-pointer" onClick={() => editRecord(record)}>
            {name}
          </p>
        );
      },
    },
    {
      title: 'Ghi chú',
      dataIndex: 'note',
    },
  ];

  if (isAccessBook) {
    tableColumns.push({
      title: '',
      width: 80,
      fixed: 'right',
      render: (record: IBookPosition) => {
        return (
          <ActionTable
            record={record}
            editRecord={() => editRecord(record)}
            showDeleteConfirm={() => showDeleteConfirm(record)}
          />
        );
      },
    });
  }

  useEffect(() => {
    !listBookPosition?.length && getListBookPosition();
  }, []);

  async function getListBookPosition() {
    const error: any = await dispatch(getListBookPositionAction());
    if (error?.length) {
      messageError(error);
    }
  }

  function addRecord() {
    setEditMode(false);
    setShowModalCreateUpdate(true);
  }
  function editRecord(record: IBookPosition) {
    setEditMode(true);
    setDataDetailBookPosition(record);
    setShowModalCreateUpdate(true);
  }
  async function deleteRecord() {
    if (!recordDelete) {
      setShowConfirmDelete(false);
      return;
    }
    setLoadingDelete(true);
    const response: any = await deleteBookPosition(recordDelete.id);
    if (response.status === ResponseStatusEnum.ERROR) {
      messageError(response.message);
    } else {
      getListBookPosition();
      notificationSuccessAndScrollToTop();
    }
    setLoadingDelete(false);
    setShowConfirmDelete(false);
  }

  const showDeleteConfirm = (recordDelete: IBookPosition) => {
    if (!recordDelete) return;
    setRecordDelete(recordDelete);
    setShowConfirmDelete(true);
  };

  return (
    <div className="list-book-position">
      <div className="flex justify-between">
        <p className="text-title mb-1">
          Tổng số giá sách: <span className="primary-color">{listBookPosition?.length}</span>
        </p>
        {isAccessBook && (
          <ButtonSecondary id="btn-add" onClick={addRecord}>
            <PlusOutlined /> Thêm
          </ButtonSecondary>
        )}
      </div>
      <TableCustom
        columns={tableColumns}
        dataSource={listBookPosition}
        scroll={{ x: 500, y: 500 }}
        pagination={{ pageSize: DEFAULT_PAGE_SIZE }}
        rowKey={(record: any) => record.id}
        loading={loading}
      />
      <ModalCreateUpdateBookPosition
        refetchData={() => getListBookPosition()}
        editMode={editMode}
        open={showModalCreateUpdate}
        onCloseModal={() => {
          setShowModalCreateUpdate(false);
          setDataDetailBookPosition(null);
        }}
        dataDetailBookPosition={dataDetailBookPosition}
      />
      <ModalConfirmDelete
        loading={loadingDelete}
        open={showConfirmDelete}
        content={recordDelete?.name}
        onCancel={() => {
          setShowConfirmDelete(false);
          setRecordDelete(null);
        }}
        onDelete={deleteRecord}
      />
    </div>
  );
};
