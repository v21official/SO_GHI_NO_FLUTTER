export enum OriginBookEnum {
  LIBRARY_FUND = 1,
  DONATE = 2,
}
export enum FormItemBook {
  CATEGORY_ID = 'bookCategoryId',
  POSITION_ID = 'bookPositionId',
  NAME = 'name',
  CODE = 'code',
  CODE_VALUE = 'codeValue',
  QTY = 'qty',
  AVAILABLE = 'available',
  NOTE = 'note',
  DESCRIPTION = 'description',
  AUTHOR = 'author',
  PUBLISHER_ID = 'publisherId',
  PUBLISH_YEAR = 'publishYear',
  ORIGIN_BOOK = 'originBook',
  ENTRY_DATE = 'entryDate',
}
export const ORIGIN_BOOK_CONFIG = [
  {
    text: 'Thư viện mua',
    value: OriginBookEnum.LIBRARY_FUND,
  },
  {
    text: 'Được ủng hộ',
    value: OriginBookEnum.DONATE,
  },
];
