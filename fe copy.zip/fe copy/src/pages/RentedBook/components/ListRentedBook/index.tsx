import React, { useEffect, useMemo, useState } from 'react';

import { PlusOutlined } from '@ant-design/icons';
import clsx from 'clsx';
import { Moment } from 'moment';

import { ModalConfirm } from 'src/components';
import { ButtonSecondary } from 'src/components/Button/ButtonSecondary';
import { TableCustom } from 'src/components/TableCustom';
import { DEFAULT_PAGE_SIZE_RENTED_BOOK, FIRST_PAGE, ResponseStatusEnum } from 'src/const';
import {
  formatDateSetFieldValue,
  formatStringDate,
  messageError,
  notificationInfo,
  notificationSuccessAndScrollToTop,
  notificationWarning,
} from 'src/helpers/fileHelper';
import { useAppDispatch, useAppSelector } from 'src/redux/hook';
import { getListRentedBookAction } from 'src/redux/slices/rentedBook.slice';
import { IParamsSearchRentedBook, IRentedBook, IRentedBookDetail, updateRentedBook } from 'src/services/rentedBook';

import './styles.scss';
import { ModalCreateRentedBook } from '../Modal/ModalCreateRentedBook';
import { ModalRentedBookDetail } from '../Modal/ModalRentedBookDetail';

import { ActionTable } from './ActionTable';
import { BookItem } from './BookItem';

type TListRentedBookProps = {
  paramsSearch: IParamsSearchRentedBook;
  setParamsSearch: React.Dispatch<React.SetStateAction<IParamsSearchRentedBook>>;
};
enum EActionOpenModal {
  UPDATE = 1,
  VIEW = 2,
}
type TRecordRentedBookSelected = {
  action: EActionOpenModal;
  data: IRentedBook;
};
function getBookCodeByRecordRentedBook(recordRentedBook?: IRentedBook) {
  if (!recordRentedBook?.rentedBookDetail?.length) return '';
  const arrayBookCode = recordRentedBook.rentedBookDetail.reduce((bookCodeArr: string[], item) => {
    if (!item.returnedDate) {
      bookCodeArr.push(item.bookCode);
    }
    return bookCodeArr;
  }, []);
  return arrayBookCode.join(' - ');
}
export const ListRentedBook = ({ paramsSearch, setParamsSearch }: TListRentedBookProps) => {
  const { loading, listRentedBook, pagination } = useAppSelector((state) => state.rentedBook);
  const dispatch = useAppDispatch();
  const [showModalCreate, setShowModalCreate] = useState(false);

  const [loadingUpdateRented, setLoadingUpdateRented] = useState(false);
  const [recordRentedBookSelected, setRecordRentedBookSelected] = useState<TRecordRentedBookSelected | undefined>(
    undefined,
  );

  const tableColumns: any = useMemo(
    () => [
      {
        title: 'Số thẻ',
        width: 80,
        render: (record: IRentedBook) => {
          return (
            <p
              className={clsx('text-base cursor-pointer font-semi-bold', !record.cardNumber && 'primary-color')}
              onClick={() => editRecord(record)}
            >
              {record.cardNumber || record.account}
            </p>
          );
        },
      },
      {
        title: 'Họ tên',
        dataIndex: 'readerName',
        width: 200,
        render: (readerName: string, record: IRentedBook) => {
          return (
            <p className="text-base cursor-pointer font-semi-bold" onClick={() => editRecord(record)}>
              {readerName}
            </p>
          );
        },
      },
      {
        title: 'Ngày mượn',
        dataIndex: 'borrowedDate',
        width: 100,
        render: (borrowedDate: string) => formatStringDate(borrowedDate),
      },
      {
        title: 'Ngày dự kiến trả',
        dataIndex: 'expectedReturnDate',
        width: 130,
        render: (expectedReturnDate: string) => formatStringDate(expectedReturnDate),
      },
      {
        title: 'Ngày trả',
        dataIndex: 'returnedDate',
        width: 130,
        render: (returnedDate: string, record: IRentedBook) => {
          if (!returnedDate) return;
          const returnedDay = formatDateSetFieldValue(returnedDate) as Moment;
          const expectedReturnDay = formatDateSetFieldValue(record.expectedReturnDate) as Moment;
          const countOverdueDate = returnedDay.diff(expectedReturnDay, 'days');
          return (
            <>
              <p className={clsx(countOverdueDate > 0 && 'error-color font-semi-bold')}>
                {formatStringDate(returnedDate)}
              </p>
              {countOverdueDate > 0 && <p className="error-color font-semi-bold">Quá hạn {countOverdueDate} ngày</p>}
            </>
          );
        },
      },
      {
        title: 'Thông tin sách',
        width: 300,
        render: (record: IRentedBook) => {
          return record.rentedBookDetail.map((item: IRentedBookDetail, index: number) => (
            <BookItem key={index} item={item} />
          ));
        },
      },
      {
        title: 'Ghi chú',
        dataIndex: 'note',
        width: 200,
      },
      {
        title: '',
        width: 80,
        fixed: 'right',
        render: (record: IRentedBook) => {
          return (
            <ActionTable
              updateRentedBook={() =>
                record.returnedDate
                  ? {}
                  : setRecordRentedBookSelected({
                      action: EActionOpenModal.UPDATE,
                      data: record,
                    })
              }
              openModalRentedBookDetail={() =>
                setRecordRentedBookSelected({
                  action: EActionOpenModal.VIEW,
                  data: record,
                })
              }
            />
          );
        },
      },
    ],
    [],
  );

  useEffect(() => {
    getListRentedBook({
      page: FIRST_PAGE,
      limit: DEFAULT_PAGE_SIZE_RENTED_BOOK,
    });
  }, []);

  function onChangePage(page: any, pageSize: any) {
    getListRentedBook({ ...paramsSearch, page, limit: pageSize });
  }

  async function getListRentedBook(params: IParamsSearchRentedBook) {
    setParamsSearch(params);
    const error: any = await dispatch(getListRentedBookAction(params));
    if (error?.length) {
      messageError(error);
    }
  }

  async function handleUpdateRentedBook() {
    if (recordRentedBookSelected?.action !== EActionOpenModal.UPDATE) return;
    setLoadingUpdateRented(true);
    const { status, message, data }: any = await updateRentedBook({
      readerId: recordRentedBookSelected.data.readerId,
      rentedBookId: recordRentedBookSelected.data.rentedBookId,
    });
    if (status === ResponseStatusEnum.ERROR) {
      messageError(message);
      setLoadingUpdateRented(false);
      return;
    }
    if (data?.countOverdueDate) {
      notificationWarning(
        `Trả sách thành công. NHƯNG QUÁ HẠN ${data.countOverdueDate} NGÀY`,
        'TNV vui lòng nhắc bạn đọc trả sách đúng hạn',
      );
    } else {
      notificationSuccessAndScrollToTop();
      if (data?.newRank) {
        notificationInfo(
          `Chúc mừng ${recordRentedBookSelected.data.readerName.toUpperCase()} đã được thăng hạng bạn đọc lên hạng ${
            data.newRank.name
          }`,
        );
      }
    }
    getListRentedBook(paramsSearch);
    setLoadingUpdateRented(false);
    setRecordRentedBookSelected(undefined);
  }

  function editRecord(record: IRentedBook) {
    setShowModalCreate(true);
  }

  return (
    <div className="list-rentedBook">
      <div className="flex justify-between">
        <p className="text-title mb-1">
          Có tất cả <span className="primary-color">{pagination?.totalItem}</span> lượt mượn sách
        </p>
        <ButtonSecondary id="btn-add" onClick={() => setShowModalCreate(true)}>
          <PlusOutlined /> Thêm
        </ButtonSecondary>
      </div>
      <TableCustom
        columns={tableColumns}
        dataSource={listRentedBook}
        scroll={{ x: 1500, y: 500 }}
        rowKey={(record: any) => record.id}
        pagination={{
          defaultPageSize: DEFAULT_PAGE_SIZE_RENTED_BOOK,
          showSizeChanger: false,
          // pageSizeOptions: [DEFAULT_PAGE_SIZE_RENTED_BOOK, 10],
          onChange: onChangePage,
          total: pagination.totalItem,
          current: pagination.currentPage,
        }}
        loading={loading}
      />
      <ModalCreateRentedBook
        refetchData={() => getListRentedBook(paramsSearch)}
        open={showModalCreate}
        onCloseModal={() => setShowModalCreate(false)}
      />
      {recordRentedBookSelected?.data && (
        <ModalRentedBookDetail
          refetchData={() => getListRentedBook(paramsSearch)}
          open={recordRentedBookSelected?.action === EActionOpenModal.VIEW}
          onCloseModal={() => setRecordRentedBookSelected(undefined)}
          rentedBook={recordRentedBookSelected.data}
        />
      )}
      <ModalConfirm
        loading={loadingUpdateRented}
        open={recordRentedBookSelected?.action === EActionOpenModal.UPDATE}
        title="Xác nhận bạn đọc trả hết sách của lượt mượn"
        content={getBookCodeByRecordRentedBook(recordRentedBookSelected?.data)}
        onCancel={() => setRecordRentedBookSelected(undefined)}
        onConfirm={handleUpdateRentedBook}
      />
    </div>
  );
};
