import { useState } from 'react';

import { CheckCircleOutlined, EyeOutlined } from '@ant-design/icons/lib/icons';

import { DropdownActionTable } from 'src/components/DropdownActionTable';
import { DropdownMenuCustom, MenuItem } from 'src/components/DropdownMenuCustom';

import './styles.scss';

type TProps = {
  updateRentedBook: () => void;
  openModalRentedBookDetail: () => void;
};
export const ActionTable = ({ updateRentedBook, openModalRentedBookDetail }: TProps) => {
  const [showMenu, setShowMenu] = useState<boolean>(false);

  const handleShowDropdown = (show: boolean) => {
    setShowMenu(show);
  };

  const _dropdownMenu = (
    <DropdownMenuCustom>
      <MenuItem
        icon={<CheckCircleOutlined className="text-xl" />}
        text="Trả toàn bộ"
        onClick={() => {
          setShowMenu(false);
          updateRentedBook();
        }}
      />
      <MenuItem
        icon={<EyeOutlined className="text-2xl" />}
        text="Xem chi tiết"
        onClick={() => {
          setShowMenu(false);
          openModalRentedBookDetail();
        }}
      />
    </DropdownMenuCustom>
  );

  return (
    <DropdownActionTable dropdownMenu={_dropdownMenu} openMenu={showMenu} handleShowDropdown={handleShowDropdown} />
  );
};
