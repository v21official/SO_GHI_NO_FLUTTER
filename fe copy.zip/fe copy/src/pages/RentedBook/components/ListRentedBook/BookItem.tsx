import { CheckCircleOutlined } from '@ant-design/icons';

import { IRentedBookDetail } from 'src/services/rentedBook';

import './styles.scss';

type TProps = {
  item: IRentedBookDetail;
};
export const BookItem = ({ item }: TProps) => {
  return (
    <div className="my-1 flex items-center">
      {!!item.returnedDate && <CheckCircleOutlined className="text-green-600 text-base pb-1 mr-2" />}
      <span>
        <span className="font-semi-bold">{item.bookCode}</span> - <span>{item.bookName}</span>
      </span>
    </div>
  );
};
