import React, { useState } from 'react';

import { QuestionCircleOutlined } from '@ant-design/icons/lib/icons';
import { Button, Col, Popover, Row } from 'antd';
import { Moment } from 'moment';

import { ButtonPrimary } from 'src/components';
import { ButtonCancel } from 'src/components/Button/ButtonCancel';
import { ModalCustom } from 'src/components/ModalCustom';
import { MESSAGE, ResponseStatusEnum } from 'src/const';
import {
  formatDateSetFieldValue,
  formatStringDate,
  messageError,
  notificationSuccessAndScrollToTop,
} from 'src/helpers';
import {
  createRentedBook,
  IBodyCreateRentedBook,
  IBookForRentedBook,
  IReaderForRentedBook,
  IRentedBook,
  IRentedBookDetail,
} from 'src/services/rentedBook';

import './styles.scss';
import { calculateOverdueDate } from '.';

interface IProps {
  item: IRentedBookDetail;
  rentedBook: IRentedBook;
}

export const BookDetail = ({ item, rentedBook }: IProps) => {
  console.log('===========BookDetail', rentedBook);
  const countOverdueDate = calculateOverdueDate(rentedBook.expectedReturnDate, item.returnedDate);

  return (
    <div className="flex justify-between items-center flex-wrap rounded-lg mb-2 book-detail">
      <div className="flex">
        <img src={item.categoryLogo} alt="the-loai-sach" className="h-12 mr-2" />
        <div className="mr-5 book-name">
          <p className="font-semi-bold primary-color">{item.bookCode}</p>
          <Popover content={item.bookName}>
            <p className="truncate">{item.bookName}</p>
          </Popover>
        </div>
      </div>
      {item.returnedDate && (
        <div>
          <p>
            Ngày trả: <span className="font-semi-bold">{formatStringDate(item.returnedDate)}</span>
          </p>
          {countOverdueDate > 0 && (
            <p className="error-color">
              Quá hạn: <span className="font-semi-bold">{countOverdueDate} ngày</span>
            </p>
          )}
        </div>
      )}
      {!item.returnedDate && (
        <div className="flex">
          <ButtonPrimary className="w-20" loading={false}>
            Trả sách
          </ButtonPrimary>
          <Button className="w-20 ml-2" loading={false}>
            Xoá
          </Button>
        </div>
      )}
    </div>
  );
};
