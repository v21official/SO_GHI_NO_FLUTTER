import React, { useState } from 'react';

import { QuestionCircleOutlined } from '@ant-design/icons/lib/icons';
import { Col, Row } from 'antd';
import { Moment } from 'moment';

import { ButtonPrimary } from 'src/components';
import { ButtonCancel } from 'src/components/Button/ButtonCancel';
import { ModalCustom } from 'src/components/ModalCustom';
import { MESSAGE, ResponseStatusEnum } from 'src/const';
import {
  formatDateSetFieldValue,
  formatStringDate,
  messageError,
  notificationSuccessAndScrollToTop,
} from 'src/helpers';
import {
  createRentedBook,
  IBodyCreateRentedBook,
  IBookForRentedBook,
  IReaderForRentedBook,
  IRentedBook,
} from 'src/services/rentedBook';

import './styles.scss';
import { BookDetail } from './BookDetail';

interface IProps {
  refetchData: () => void;
  onCloseModal: () => void;
  open: boolean;
  rentedBook: IRentedBook;
}

export function calculateOverdueDate(expectedReturnDate = '', returnedDate = '') {
  if (!expectedReturnDate || !returnedDate) return 0;
  const returnedDay = formatDateSetFieldValue(returnedDate) as Moment;
  const expectedReturnDay = formatDateSetFieldValue(expectedReturnDate) as Moment;
  return returnedDay.diff(expectedReturnDay, 'days');
}

export const ModalRentedBookDetail = ({ refetchData, open, onCloseModal, rentedBook }: IProps) => {
  const [loading, setLoading] = useState(false);
  console.log('===========ModalRentedBookDetail', rentedBook);
  const countOverdueDate = calculateOverdueDate(rentedBook.expectedReturnDate, rentedBook.returnedDate);

  const submit = async () => {
    setLoading(true);
    const body: any = {};
    const response: any = await createRentedBook(body);
    if (response.status === ResponseStatusEnum.ERROR) {
      messageError(response.message);
      setLoading(false);
      return;
    }
    setLoading(false);
    onCloseModal();
    notificationSuccessAndScrollToTop();
    refetchData();
  };

  return (
    <ModalCustom
      destroyOnClose={true}
      open={open}
      title="Thông tin chi tiết lượt mượn sách"
      className="modal-rented-book-detail"
      width={700}
      loading={loading}
      onCancel={onCloseModal}
    >
      <div className="flex flex-col items-center mb-5">
        <p className="font-semi-bold text-2xl primary-color">{rentedBook.readerName}</p>
        <p>Số thẻ: {rentedBook.cardNumber || rentedBook.account}</p>
      </div>
      <Row className="mb-8">
        <Col md={24} lg={15} className="pr-5 mt-3">
          <p>
            Ngày mượn: <span className="font-semi-bold">{formatStringDate(rentedBook.borrowedDate)}</span>
          </p>
          <p>
            TNV cho mượn:{' '}
            <span className="font-semi-bold">
              {rentedBook.borrowedConfirmMemberAccount} - {rentedBook.borrowedConfirmMemberName}
            </span>
          </p>
        </Col>
        <Col md={24} lg={9} className="mt-3">
          <p>
            Ngày trả dự kiến: <span className="font-semi-bold">{formatStringDate(rentedBook.expectedReturnDate)}</span>
          </p>
          <p>
            Ngày trả toàn bộ: <span className="font-semi-bold">{formatStringDate(rentedBook.returnedDate || '')}</span>
          </p>
        </Col>
      </Row>
      {rentedBook.rentedBookDetail.map((item) => (
        <BookDetail key={item.rentedBookDetailId} item={item} rentedBook={rentedBook} />
      ))}
      <div className="flex justify-center mt-8">
        <ButtonCancel id="btn-cancel" className="w-20" onClick={onCloseModal}>
          Thoát
        </ButtonCancel>
      </div>
    </ModalCustom>
  );
};
