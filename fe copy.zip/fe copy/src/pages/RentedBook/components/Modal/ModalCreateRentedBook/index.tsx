import React, { useState } from 'react';

import { Col, Row } from 'antd';
import TextArea from 'antd/lib/input/TextArea';

import { ButtonPrimary } from 'src/components';
import { ButtonCancel } from 'src/components/Button/ButtonCancel';
import { ModalCustom } from 'src/components/ModalCustom';
import { MESSAGE, ResponseStatusEnum } from 'src/const';
import { messageError, notificationSuccessAndScrollToTop } from 'src/helpers';
import {
  createRentedBook,
  IBodyCreateRentedBook,
  IBookForRentedBook,
  IReaderForRentedBook,
} from 'src/services/rentedBook';

import './styles.scss';
import SelectBook from './SelectBook';
import SelectReader from './SelectReader';

interface IProps {
  refetchData: () => void;
  onCloseModal: () => void;
  open: boolean;
}

export const ModalCreateRentedBook = ({ refetchData, open, onCloseModal }: IProps) => {
  const [loading, setLoading] = useState(false);
  const [readerSelected, setReaderSelected] = useState<IReaderForRentedBook | undefined>(undefined);
  const [bookSelected, setBookSelected] = useState<IBookForRentedBook[]>([]);
  const noteRef: any = React.useRef(null);

  const closeModal = () => {
    readerSelected && setReaderSelected(undefined);
    bookSelected.length && setBookSelected([]);
    onCloseModal();
  };

  const submit = async () => {
    if (!readerSelected) {
      messageError(MESSAGE.createRentedRequireReader);
      return;
    }
    if (!bookSelected.length) {
      messageError(MESSAGE.createRentedRequireBook);
      return;
    }
    setLoading(true);
    const body: IBodyCreateRentedBook = {
      readerId: readerSelected.readerId,
      listBookId: bookSelected.map((item) => item.id),
      note: noteRef.current?.resizableTextArea?.textArea?.value,
    };
    const response: any = await createRentedBook(body);
    if (response.status === ResponseStatusEnum.ERROR) {
      messageError(response.message);
      setLoading(false);
      return;
    }
    setLoading(false);
    closeModal();
    notificationSuccessAndScrollToTop();
    refetchData();
  };

  return (
    <ModalCustom
      destroyOnClose={true}
      open={open}
      title="Tạo lượt mượn sách"
      className="modal-create-rented-book"
      width={800}
      loading={loading}
      onCancel={closeModal}
    >
      <Row>
        <Col span={10} className="pr-5">
          <SelectReader readerSelected={readerSelected} setReaderSelected={setReaderSelected} />
        </Col>
        <Col span={14} className="pl-5">
          <SelectBook bookSelected={bookSelected} setBookSelected={setBookSelected} />
        </Col>
      </Row>
      <TextArea ref={noteRef} className="mt-8" placeholder="Ghi chú" rows={3} maxLength={500} showCount />
      <div className="flex mt-8">
        <ButtonCancel id="btn-cancel" className="w-full mr-2" onClick={onCloseModal}>
          Thoát
        </ButtonCancel>
        <ButtonPrimary id="btn-save" className="w-full ml-2" onClick={submit}>
          Lưu
        </ButtonPrimary>
      </div>
    </ModalCustom>
  );
};
