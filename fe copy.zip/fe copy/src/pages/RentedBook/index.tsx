import React, { useState } from 'react';

import { DEFAULT_PAGE_SIZE_RENTED_BOOK, FIRST_PAGE } from 'src/const';
import { IParamsSearchRentedBook } from 'src/services/rentedBook';

import Card from '../../components/Card';

import { ListRentedBook, SearchRentedBook } from './components';

import './styles.scss';

export const RentedBook: React.FC = () => {
  const [paramsSearch, setParamsSearch] = useState<IParamsSearchRentedBook>({
    page: FIRST_PAGE,
    limit: DEFAULT_PAGE_SIZE_RENTED_BOOK,
  });
  return (
    <div className="rentedBook-page">
      <Card>
        <SearchRentedBook paramsSearch={paramsSearch} setParamsSearch={setParamsSearch} />
      </Card>
      <Card className="mt-10">
        <ListRentedBook paramsSearch={paramsSearch} setParamsSearch={setParamsSearch} />
      </Card>
    </div>
  );
};
