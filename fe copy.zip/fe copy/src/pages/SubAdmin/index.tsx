import React from 'react';

import './style.scss';

export const SubAdminPage: React.FC = () => {
  return <p>SubAdminPage</p>;
};
