import React from 'react';

export const Profile: React.FC = () => {
  return <p>Profile</p>;
};
