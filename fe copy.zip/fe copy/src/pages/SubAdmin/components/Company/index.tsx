import React from 'react';

export const Company: React.FC = () => {
  return <p>Company</p>;
};
