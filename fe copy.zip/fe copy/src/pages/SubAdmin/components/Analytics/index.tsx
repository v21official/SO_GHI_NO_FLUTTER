import React from 'react';

export const Analytics: React.FC = () => {
  return <p>Analytics</p>;
};
