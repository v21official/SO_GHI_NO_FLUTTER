import React from 'react';

import Card from '../../components/Card';

import { ListBookCategory } from './components';

import './styles.scss';

export const BookCategory: React.FC = () => {
  return (
    <div className="book-category-page">
      <Card>
        <ListBookCategory />
      </Card>
    </div>
  );
};
