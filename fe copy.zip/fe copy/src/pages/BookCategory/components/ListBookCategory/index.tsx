import React, { useEffect, useState } from 'react';

import { PlusOutlined } from '@ant-design/icons';

import { ButtonSecondary } from 'src/components/Button/ButtonSecondary';
import { ModalConfirmDelete } from 'src/components/ModalConfirmDelete';
import { TableCustom } from 'src/components/TableCustom';
import { DEFAULT_PAGE_SIZE, ResponseStatusEnum } from 'src/const';
import { messageError, notificationSuccessAndScrollToTop } from 'src/helpers/fileHelper';
import { usePermission } from 'src/hooks/usePermission';
import { useAppDispatch, useAppSelector } from 'src/redux/hook';
import { getListBookCategoryAction } from 'src/redux/slices/bookCategory.slice';
import { deleteBookCategory, IBookCategory } from 'src/services/bookCategory';

import { ModalCreateUpdateBookCategory } from '../ModalCreateUpdateBookCategory';

import { ActionTable } from './ActionTable';

import './styles.scss';

export const ListBookCategory = () => {
  const { loading, listBookCategory } = useAppSelector((state) => state.bookCategory);
  const { isAccessBook } = usePermission();
  const dispatch = useAppDispatch();
  const [editMode, setEditMode] = useState(false);
  const [showModalCreateUpdate, setShowModalCreateUpdate] = useState(false);
  const [dataDetailBookCategory, setDataDetailBookCategory] = useState<IBookCategory | null>(null);

  const [loadingDelete, setLoadingDelete] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [recordDelete, setRecordDelete] = useState<IBookCategory | null>(null);

  const tableColumns: any = [
    {
      title: 'Logo',
      dataIndex: 'logo',
      width: 120,
      render: (logo: string) => <img className="h-10" src={logo} alt="logo" />,
    },
    {
      title: 'Thể loại sách',
      dataIndex: 'name',
      width: 250,
      render: (name: string, record: IBookCategory) => {
        return (
          <p className="font-semi-bold cursor-pointer" onClick={() => editRecord(record)}>
            {name}
          </p>
        );
      },
    },
    {
      title: 'Mã thể loại',
      dataIndex: 'code',
      width: 150,
    },
    {
      title: 'Số điểm',
      dataIndex: 'point',
      width: 100,
    },
    {
      title: 'Mô tả',
      dataIndex: 'description',
      width: 300,
    },
  ];

  if (isAccessBook) {
    tableColumns.push({
      title: '',
      width: 80,
      fixed: 'right',
      render: (record: IBookCategory) => {
        return (
          <ActionTable
            record={record}
            editRecord={() => editRecord(record)}
            showDeleteConfirm={() => showDeleteConfirm(record)}
          />
        );
      },
    });
  }

  useEffect(() => {
    !listBookCategory?.length && getListBookCategory();
  }, []);

  async function getListBookCategory() {
    const error: any = await dispatch(getListBookCategoryAction());
    if (error?.length) {
      messageError(error);
    }
  }

  function addRecord() {
    setEditMode(false);
    setShowModalCreateUpdate(true);
  }
  function editRecord(record: IBookCategory) {
    setEditMode(true);
    setDataDetailBookCategory(record);
    setShowModalCreateUpdate(true);
  }
  async function deleteRecord() {
    if (!recordDelete) {
      setShowConfirmDelete(false);
      return;
    }
    setLoadingDelete(true);
    const response: any = await deleteBookCategory(recordDelete.id);
    if (response.status === ResponseStatusEnum.ERROR) {
      messageError(response.message);
    } else {
      getListBookCategory();
      notificationSuccessAndScrollToTop();
    }
    setLoadingDelete(false);
    setShowConfirmDelete(false);
  }

  const showDeleteConfirm = (recordDelete: IBookCategory) => {
    if (!recordDelete) return;
    setRecordDelete(recordDelete);
    setShowConfirmDelete(true);
  };

  return (
    <div className="list-book-category">
      <div className="flex justify-between">
        <p className="text-title mb-1">
          Tổng số thể loại sách: <span className="primary-color">{listBookCategory?.length}</span>
        </p>
        {isAccessBook && (
          <ButtonSecondary id="btn-add" onClick={addRecord}>
            <PlusOutlined /> Thêm
          </ButtonSecondary>
        )}
      </div>
      <TableCustom
        columns={tableColumns}
        dataSource={listBookCategory}
        scroll={{ x: 800, y: 500 }}
        pagination={{ pageSize: DEFAULT_PAGE_SIZE }}
        rowKey={(record: any) => record.id}
        loading={loading}
      />
      <ModalCreateUpdateBookCategory
        refetchData={() => getListBookCategory()}
        editMode={editMode}
        open={showModalCreateUpdate}
        onCloseModal={() => {
          setShowModalCreateUpdate(false);
          setDataDetailBookCategory(null);
        }}
        dataDetailBookCategory={dataDetailBookCategory}
      />
      <ModalConfirmDelete
        loading={loadingDelete}
        open={showConfirmDelete}
        content={recordDelete?.name}
        onCancel={() => {
          setShowConfirmDelete(false);
          setRecordDelete(null);
        }}
        onDelete={deleteRecord}
      />
    </div>
  );
};
