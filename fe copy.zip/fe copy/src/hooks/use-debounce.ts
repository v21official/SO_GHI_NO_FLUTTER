import { useCallback } from 'react';

import { debounce } from 'lodash';

export const useDebounce = (fnToDebounce: (value: any) => void, durationInMs: number = 200, depend?: any) => {
  return useCallback(
    debounce((value) => fnToDebounce(value), durationInMs),
    [depend],
  );
};

export default useDebounce;
