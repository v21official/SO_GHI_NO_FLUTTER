import React, { useCallback, useLayoutEffect } from 'react';

import { Route, useHistory } from 'react-router-dom';

import { localStorageHelper } from 'src/helpers';
import { SideBarRoute } from 'src/layouts/Main/main.type';
import { useAppSelector } from 'src/redux/hook';
import { IRoute } from 'src/routes/config';

import { SkeletonDefault } from '../SkeletonDefault';

interface IRestrictedRouteProps extends IRoute {
  isPrivate?: boolean;
}

export const RestrictedRoute: React.FC<IRestrictedRouteProps> = ({
  children,
  restricted = false,
  isPrivate,
  layout: Layout,
  ...props
}) => {
  const { loadingAppState } = useAppSelector((state) => state.app);
  const history = useHistory();
  const redirect = useCallback(() => {
    if (isPrivate && !localStorageHelper.isLogin()) {
      history.replace(SideBarRoute.LOGIN);
      return;
    }
    if (restricted && localStorageHelper.isLogin()) {
      history.replace(SideBarRoute.HOME);
      return;
    }
  }, [isPrivate, history, restricted]);

  useLayoutEffect(() => {
    redirect();
  }, [redirect]);

  const Component = Layout ? <Layout>{loadingAppState ? <SkeletonDefault /> : children}</Layout> : children;

  return <Route {...props}>{Component}</Route>;
};
