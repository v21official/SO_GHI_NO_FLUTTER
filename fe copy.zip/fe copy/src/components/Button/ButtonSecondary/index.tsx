import React from 'react';

import { Button } from 'antd';
import clsx from 'clsx';

import './button-secondary.scss';
import { TButton } from '../../../types';

export const ButtonSecondary: React.FC<TButton> = ({ children, ...rest }) => {
  const classButtonSecondary = clsx('secondary-button', rest.className && rest.className);
  return (
    <Button {...rest} className={classButtonSecondary} type="text">
      {children}
    </Button>
  );
};
