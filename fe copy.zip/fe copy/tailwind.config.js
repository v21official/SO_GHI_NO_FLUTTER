module.exports = {
  purge: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {},
    maxWidth: {
      '1/4': '25%',
      '1/2': '50%',
      '3/4': '75%',
      '32em': '32em',
      vw: '100vw',
    },
    maxHeight: {
      'vh-66px-12': 'calc(100vh - 66px - 3rem)',
      'vh-74px': 'calc(100vh - 74px)',
    },
    fontFamily: {
      roboto: ['Nunito', 'sans-serif'],
      sans: ['Nunito', 'sans-serif'],
      serif: ['Nunito', 'serif'],
    },
    zIndex: {
      100: '100',
      '-10': '-10',
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
